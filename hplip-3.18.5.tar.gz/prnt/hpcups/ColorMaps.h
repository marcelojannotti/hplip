extern uint32_t ulMapDJ400_K[9 * 9 * 9];
extern uint32_t ulMapDJ400_CMY[9 * 9 * 9];

extern uint32_t ulMapDJ600_CCM_K[ 9 * 9 * 9 ];
extern uint32_t ulMapDJ600_CCM_K[ 9 * 9 * 9 ];
extern uint32_t ulMapDJ600_CCM_CMY[ 9 * 9 * 9 ];
extern uint32_t ulMapDJ660_CCM_KCMY[ 9 * 9 * 9 ];
extern uint32_t ulMapDJ690_CMYK[ 9 * 9 * 9 ];
extern uint32_t ulMapGRAY_K_6x6x1[9 * 9 * 9];
extern uint32_t ulMapDJ690_ClMlxx[9 * 9 * 9];

extern uint32_t ulMapDJ850_Normal_KCMY[9 * 9 * 9];

extern uint32_t ulMapDJ895_KCMY[ 9 * 9 * 9 ];
extern uint32_t ulMapDJ895_HB_KCMY[ 9 * 9 * 9 ];
extern uint32_t ulMapDJ895_Binary_KCMY[ 9 * 9 * 9 ];

extern uint32_t ulMapDJ8x5PlainNormal[ 9 * 9 * 9 ];
extern uint32_t ulMapDJ8x5Draft[ 9 * 9 * 9 ];

extern uint32_t ulMapDJ970_KCMY[9 * 9 * 9];
extern uint32_t ulMapDJ970_KCMY_3x3x2[9 * 9 * 9];
extern uint32_t ulMapDJ970_Gossimer_Normal_KCMY[9 * 9 * 9];
extern uint32_t ulMapDJ600_CCM_K[9 * 9 * 9];
extern uint32_t ulMapGRAY_K_6x6x1[9 * 9 * 9];
extern uint32_t ulMapDJ970_Draft_KCMY[9 * 9 * 9];

extern uint32_t ulMapDJ3320_K_3x3x1[9 * 9 * 9];
extern uint32_t ulMapDJ3320_K_6x6x1[9 * 9 * 9];
extern uint32_t ulMapDJ3320_CMY_3x3x1[9 * 9 * 9];
extern uint32_t ulMapDJ3320_CMY_6x6x1[9 * 9 * 9];
extern uint32_t ulMapDJ3320_KCMY_3x3x1[9 * 9 * 9];
extern uint32_t ulMapDJ3320_KCMY_6x6x1[9 * 9 * 9];
extern uint32_t ulMapDJ970_Gossimer_Normal_KCMY[ 9 * 9 * 9 ];

extern uint32_t ulMapDJ3600_KCMY_6x6x1[9 * 9 * 9];
extern uint32_t ulMapDJ3600_ClMlxx_6x6x1[9 * 9 * 9];
extern uint32_t ulMapDJ3600_KCMY_6x6x2[9 * 9 * 9];
extern uint32_t ulMapDJ3600_ClMlxx_6x6x2[9 * 9 * 9];
extern uint32_t ulMapDJ3600_KCMY_3x3x1[9 * 9 * 9];
extern uint32_t ulMapDJ3600_ClMlxx_3x3x1[9 * 9 * 9];

extern unsigned char ucMapDJ4100_KCMY_6x6x1[];
extern unsigned char ucMapDJ4100_KCMY_Photo_BestV_12x12x1[];
extern unsigned char ucMapDJ4100_KCMY_Photo_BestA_12x12x1[];

extern unsigned char ucMapDJ4100_KCMY_Photo_BestA_12x12x1[17 * 17 * 17];
